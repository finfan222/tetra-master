package com.finfan.server.enums;

public enum Permission {

    PLAYER,
    GM,
    ADMIN,
    BANNED;

}
