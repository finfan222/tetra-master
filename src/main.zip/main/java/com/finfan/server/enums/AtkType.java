package com.finfan.server.enums;

public enum AtkType {
    P,
    M,
    X,
    A
}
