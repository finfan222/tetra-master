package com.finfan.server.enums;

public enum Portrait {
    ZIDANE,
    VIVI,
    GARNET,
    GARNET_2,
    STEINER,
    QUEENA,
    EIKO,
    FREYA,
    AMARANT,
    CINA,
    MARKUS,
    BLANK,
    BEATRIX
}
