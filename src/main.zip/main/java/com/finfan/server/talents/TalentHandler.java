package com.finfan.server.talents;

public interface TalentHandler {
}
