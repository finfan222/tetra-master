package com.finfan.server.talents;

public class HandlerPhoenixDown implements TalentHandler {
}
