package com.finfan.server.talents;

public class HandlerLucky7 implements TalentHandler {
}
